# Prediction-of-Disease-Outbreak

Here is the link of the deployed model:-
https://prediction-of-disease-outbreak-qfvoaak358o9q6odwepeos.streamlit.app/
